package com.example.demo.producer;

import static org.junit.jupiter.api.Assertions.*;

class ProducerTest {

}