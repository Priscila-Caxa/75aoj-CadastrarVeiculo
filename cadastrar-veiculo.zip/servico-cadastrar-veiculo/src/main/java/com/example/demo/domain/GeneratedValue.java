package com.example.demo.domain;

/**
 *
 */
public @interface GeneratedValue {
}
