package com.example.demo.services;

import com.example.demo.repository.Veiculo;

import java.util.Optional;

public class VeiculoRepository {
    public void save(Veiculo veiculo1) {
    }

    public Optional<com.example.demo.domain.Veiculo> findById(Integer id) {
    }
}
