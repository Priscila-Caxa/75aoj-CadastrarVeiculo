package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

class CadastroVeiculoApplicationTest {

}