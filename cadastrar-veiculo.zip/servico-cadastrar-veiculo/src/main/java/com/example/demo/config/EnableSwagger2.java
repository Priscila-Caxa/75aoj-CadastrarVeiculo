package com.example.demo.config;

public @interface EnableSwagger2 {
}
