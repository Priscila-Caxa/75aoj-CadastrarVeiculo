package com.example.demo;

public class SpringApplication {
    public static void run(Class<CadastroVeiculoApplication> cadastroVeiculoApplicationClass, String[] args) {
    }
}
