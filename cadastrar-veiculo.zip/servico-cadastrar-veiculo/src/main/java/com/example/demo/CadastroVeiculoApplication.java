package com.example.demo;

import org.springframework.boot.SpringBootApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroVeiculoApplication {

	public static void main(String[] args) {
		SpringBootApplication.run(CadastroVeiculoApplication.class, args);
	}

}
