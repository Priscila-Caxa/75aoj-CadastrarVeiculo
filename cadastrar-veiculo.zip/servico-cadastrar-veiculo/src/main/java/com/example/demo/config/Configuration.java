package com.example.demo.config;

public @interface Configuration {
}
