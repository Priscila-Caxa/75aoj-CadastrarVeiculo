package com.example.demo.resources;

public @interface Autowired {
}
