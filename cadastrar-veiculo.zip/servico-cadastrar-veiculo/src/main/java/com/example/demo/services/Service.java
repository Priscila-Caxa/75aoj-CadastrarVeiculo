package com.example.demo.services;

@interface Service {
}
