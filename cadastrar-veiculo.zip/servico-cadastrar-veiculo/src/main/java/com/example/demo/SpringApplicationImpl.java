package com.example.demo;

public class SpringApplicationImpl extends SpringApplication {
}
