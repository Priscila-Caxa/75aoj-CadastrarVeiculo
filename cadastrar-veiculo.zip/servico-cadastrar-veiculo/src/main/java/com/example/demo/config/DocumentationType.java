package com.example.demo.config;

public class DocumentationType {
    public static final Object SWAGGER_2 = ;
}
