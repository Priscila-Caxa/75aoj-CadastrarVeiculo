package com.example.demo.resources;

import static org.junit.jupiter.api.Assertions.*;

class ResponseEntityTest {

}