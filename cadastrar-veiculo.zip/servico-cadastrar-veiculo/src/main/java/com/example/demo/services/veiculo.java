package com.example.demo.services;

import com.example.demo.repository.Veiculo;

public class veiculo implements Veiculo {
    public veiculo(Object o, String s, String iveco, String daily, String dpj1234, String vuc, String s1, String s2) {
    }
}
