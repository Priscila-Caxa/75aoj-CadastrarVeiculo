package com.example.demo.resources;public class RequestMethod {
}
