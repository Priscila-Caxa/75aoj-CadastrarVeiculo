package com.example.demo.config;

import java.util.ArrayList;

public class ApiInfo {
    public ApiInfo(String cadastro_de_veiculos, String s, String s1, String s2, Contact priscila_caxa, String s3, String s4, ArrayList<VendorExtension> vendorExtensions) {
    }
}
