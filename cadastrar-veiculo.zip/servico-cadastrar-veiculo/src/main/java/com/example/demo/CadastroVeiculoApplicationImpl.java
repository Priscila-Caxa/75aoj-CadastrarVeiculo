package com.example.demo;

public class CadastroVeiculoApplicationImpl extends CadastroVeiculoApplication {
}
