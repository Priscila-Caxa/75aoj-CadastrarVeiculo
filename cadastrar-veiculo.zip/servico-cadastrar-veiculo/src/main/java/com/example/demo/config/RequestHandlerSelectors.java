package com.example.demo.config;

public class RequestHandlerSelectors {
    public static Object basePackage(String s) {
    }
}
