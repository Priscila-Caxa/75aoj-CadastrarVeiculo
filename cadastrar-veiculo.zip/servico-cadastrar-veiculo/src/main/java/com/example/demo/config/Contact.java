package com.example.demo.config;

public class Contact {
    public Contact(String priscila_caxa, String s, String s1) {
    }
}
