package com.example.demo;

@interface SpringBootApplication {
}
